<footer class="main-footer">
		<div class="container">
			<div class="f_left">
				<p>&copy; VictorSoccer</p>
		
	</footer>
	<?php wp_footer(); ?>
</body>
</html>